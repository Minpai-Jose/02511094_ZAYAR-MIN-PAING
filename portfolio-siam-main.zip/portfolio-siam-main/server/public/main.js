/* ウェブデザイン 第6回 最終課題:作品一覧を API から描画する(works.html で読み込む)
   STEP を1つずつ有効にして、保存 → ブラウザで確かめる。
   注意:node server.js で起動し、http://localhost:3000/ で開くこと。 */

/* ---- STEP 1 API から取りに行く(fetch) ---- */
fetch("/api/works")
  .then((response) => response.json())   // 届いた文字列を、配列と辞書に変える
  .then((works) => {
    console.log(works);                   // まずコンソールで中身を見る
    showWorks(works);                     // STEP 2 で作る
  })
  .catch((error) => {
    console.error("API から読めません", error);
  });

/* ---- STEP 2 1件ずつカードにして、ul の中に追加する ----
   第6回で書きかえ:クライアントが管理画面から入れた文字をそのまま innerHTML に入れると、
   <mark> や <script> がHTMLとして動いてしまう(XSS)。文字は textContent で入れる */
function showWorks(works) {
  const list = document.querySelector("#work-list");

  /* 要望A:「先頭に出す」が付いた作品だけを先頭へ。ほかの作品の順番は変えない
     (sort は同じ値どうしの順番を保つ) */
  works.sort((a, b) => Number(b.featured === true) - Number(a.featured === true));

  if (works.length === 0) {
    list.innerHTML = "<li>作品はまだありません</li>";
    return;
  }
  works.forEach((work) => {
    const li = document.createElement("li");
    li.className = "work-card";
    if (work.featured) li.classList.add("work-card-featured");

    const a = document.createElement("a");
    a.href = `work.html?id=${work.id}`;

    const img = document.createElement("img");
    img.src = work.image;
    img.alt = work.alt;

    // 作品一覧のページは h1 の次なので h2(見出しの順番を飛ばさない。Lighthouse で確認)
    const h3 = document.createElement("h2");
    h3.textContent = work.title;                       // 文字として入れる

    const p = document.createElement("p");
    p.textContent = `${work.year} / ${work.tools}`;    // 文字として入れる

    a.append(img);
    if (work.featured) {
      // 要望A:色だけでなく、文字でも「一番見てほしい作品」だと分かる
      const badge = document.createElement("p");
      badge.className = "badge";
      badge.textContent = "いちばん見てほしい作品";
      a.append(badge);
    }
    a.append(h3, p);
    li.appendChild(a);
    list.appendChild(li);
  });
}

/* ---- 発展 ----
   1. works.json に5件目を足して、HTMLを触らずに一覧が増えることを確かめる
   2. 新しい順に並べる:works.reverse() を forEach の前に入れる
   3. 管理画面で作品名に <mark>目立つ</mark> と入れて、一覧で色が付かず、そのまま文字で出ることを確かめる */
